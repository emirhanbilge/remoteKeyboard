Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/hid_keyboard_shortcuts.py
    :caption: examples/hid_keyboard_shortcuts.py
    :linenos:

.. literalinclude:: ../examples/hid_simpletest.py
    :caption: examples/hid_simpletest.py
    :linenos:

.. literalinclude:: ../examples/hid_simple_gamepad.py
    :caption: examples/hid_simple_gamepad.py
    :linenos:

.. literalinclude:: ../examples/hid_joywing_gamepad.py
    :caption: examples/hid_joywing_gamepad.py
    :linenos:
